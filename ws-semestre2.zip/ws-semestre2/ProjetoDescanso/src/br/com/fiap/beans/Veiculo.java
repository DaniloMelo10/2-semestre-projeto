package br.com.fiap.beans;

public class Veiculo {
	private String modelo;
	private String cor;
	private String placa;
	private int ano;
	private double valorVenda;
	private double valorCompra;
	public Veiculo(String modelo, String cor, String placa, int ano, double valorVenda, double valorCompra) {
		super();
		this.modelo = modelo;
		this.cor = cor;
		this.placa = placa;
		this.ano = ano;
		this.valorVenda = valorVenda;
		this.valorCompra = valorCompra;
	}
	public Veiculo() {
		super();
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public double getValorVenda() {
		return valorVenda;
	}
	public void setValorVenda(double valorVenda) {
		this.valorVenda = valorVenda;
	}
	public double getValorCompra() {
		return valorCompra;
	}
	public void setValorCompra(double valorCompra) {
		this.valorCompra = valorCompra;
	}

}
