package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Veiculo;
import br.com.fiap.conexao.Conexao;

public class VeiculoDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	public VeiculoDAO() throws Exception{
		con = Conexao.conectar();
	}
	public String gravar(Veiculo v)throws Exception{
		stmt = con.prepareStatement("INSERT INTO T_DDD_VEICULO "
				+ "(NR_PLACA, DS_MODELO, NM_COR, NR_ANO, VL_COMPRA, VL_VENDA) "
				+ "VALUES (?,?,?,?,?,?)");
		stmt.setString(1, v.getPlaca());
		stmt.setString(2, v.getModelo());
		stmt.setString(3, v.getCor());
		stmt.setInt(4, v.getAno());
		stmt.setDouble(5, v.getValorCompra());
		stmt.setDouble(6, v.getValorVenda());
		stmt.execute();
		return "Adicionado com sucesso!";
	}
	public int depreciar()throws Exception {
		stmt = con.prepareStatement("UPDATE T_DDD_VEICULO SET VL_VENDA=VL_VENDA*0.97");
		return stmt.executeUpdate();
	}
	
	public int apagarPorAno(int ano) throws Exception{
		stmt = con.prepareStatement("DELETE FROM T_DDD_VEICULO WHERE NR_ANO=?");
		stmt.setInt(1, ano);
		return stmt.executeUpdate();
	}
	
	public int atualizar(Veiculo v) throws Exception{
		stmt = con.prepareStatement("UPDATE T_DDD_VEICULO "
				+ "SET VL_VENDA=?, VL_COMPRA=?, NM_COR=?, DS_MODELO=?, NR_ANO=? "
				+ "WHERE NR_PLACA=?");
		stmt.setDouble(1, v.getValorVenda());
		stmt.setDouble(2, v.getValorCompra());
		stmt.setString(3, v.getCor());
		stmt.setString(4, v.getModelo());
		stmt.setInt(5, v.getAno());
		stmt.setString(6, v.getPlaca());
		return stmt.executeUpdate();
	}
	public Veiculo consultarPorPlaca(String placa)throws Exception{
		stmt = con.prepareStatement("SELECT * FROM T_DDD_VEICULO WHERE NR_PLACA=?");
		stmt.setString(1, placa);
		rs = stmt.executeQuery();
		if (rs.next()) {
			return new Veiculo(
					rs.getString("DS_MODELO"), 
					rs.getString("NM_COR"), 
					rs.getString("NR_PLACA"), 
					rs.getInt("NR_ANO"), 
					rs.getDouble("VL_VENDA"), 
					rs.getDouble("VL_COMPRA")
					);
		}else {
			return new Veiculo();
		}
	}
	public List<Veiculo> consultarPorModelo(String modelo)throws Exception{
		List<Veiculo> lista = new ArrayList<Veiculo>();
		stmt = con.prepareStatement("SELECT * FROM T_DDD_VEICULO WHERE DS_MODELO LIKE ?");
		stmt.setString(1, modelo + "%");
		rs = stmt.executeQuery();
		while (rs.next()) {
			lista.add(new Veiculo(
					rs.getString("DS_MODELO"), 
					rs.getString("NM_COR"), 
					rs.getString("NR_PLACA"), 
					rs.getInt("NR_ANO"), 
					rs.getDouble("VL_VENDA"), 
					rs.getDouble("VL_COMPRA")
					));
		}
		return lista;
	}
	
	public void fechar() throws Exception{
		con.close();
	}
	
}













