package br.com.fiap.teste;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.excecao.Excecao;

public class TesteAtualizarApagar {

	public static void main(String[] args) {
		try {
			ClienteDAO dao = new ClienteDAO();
			int numero= Integer.parseInt
					(JOptionPane.showInputDialog
					("Digite o n�mero do cliente"));
			char resposta = JOptionPane.showInputDialog("Digite:\n"
					+ "<A> para apagar\n"
					+ "<P> para promover").toUpperCase().charAt(0);
			if (resposta=='A') {
				System.out.println("Clientes apagados: " + dao.apagar(numero));
			}else if(resposta=='P') {
				System.out.println("Cliente promovido: " + dao.promover(numero));
			}else {
				System.out.println("Op��o inv�lida");
			}
			for (Cliente cli : dao.consultarPorNome("")) {
				System.out.println("Nome.....: " + cli.getNome());
				System.out.println("N�mero...: " + cli.getNumero());
				System.out.println("Estrelas.:" + cli.getQtdeEstrelas());
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(Excecao.tratarExcecao(e));
			
		}

	}

}
