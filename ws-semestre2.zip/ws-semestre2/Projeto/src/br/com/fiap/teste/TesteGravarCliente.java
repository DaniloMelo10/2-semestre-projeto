package br.com.fiap.teste;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.beans.Endereco;
import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.excecao.Excecao;

public class TesteGravarCliente {

	public static void main(String[] args) {
		try {
			System.out.println(
					new ClienteDAO().gravar
					(new Cliente
					(JOptionPane.showInputDialog("Digite o nome"),
					Integer.parseInt(JOptionPane.showInputDialog("Digite o n�mero")),
					Integer.parseInt(JOptionPane.showInputDialog("Digite a qtde estrelas"
					)),
					new Endereco(
							Integer.parseInt(JOptionPane.showInputDialog("C�digo")),
							JOptionPane.showInputDialog("Logradouro"),
							JOptionPane.showInputDialog("N�mero"),
							JOptionPane.showInputDialog("CEP"))
							)));
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(Excecao.tratarExcecao(e));
		}

	}

}



