package br.com.fiap.teste;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.excecao.Excecao;

public class TesteConsultarCliente {

	public static void main(String[] args) {
		try {
			Cliente cli = new Cliente();
			ClienteDAO dao = new ClienteDAO();
			cli = dao.consultarPorNumero(Integer.parseInt
					(JOptionPane.showInputDialog("Digite o n�mero: ")));
			System.out.println("Nome.....:" + cli.getNome());
			System.out.println("Estrelas.:" + cli.getQtdeEstrelas());
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(Excecao.tratarExcecao(e));
		}

	}

}










