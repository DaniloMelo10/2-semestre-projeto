package br.com.fiap.teste;

import java.util.HashMap;
import java.util.Map;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cargo;

public class TesteMap {

	public static void main(String[] args) {
		Map<String, Cargo> mapa = new HashMap<String, Cargo>();
		mapa.put("50", new Cargo("DEV", 3000, "JUNIOR"));
		mapa.put("150", new Cargo("DEV", 5000, "PLENO"));
		mapa.put("5", new Cargo("DEV", 8000, "SENIOR"));
		System.out.println(mapa);
		System.out.println("Chaves: " + mapa.keySet());
		double sal = Double.parseDouble
				(JOptionPane.showInputDialog
				("Salario a ser pesquisado: "));
		
		for(Cargo c : mapa.values()) {
			if(c.getSalario()>sal) {
				System.out.println("Cargo...: " + c.getNome());
				System.out.println("N�vel...: " + c.getNivel());
				System.out.println("Sal�rio.: " + c.getSalario());
			}
		}
		//POGA�A
		//System.out.println(mapa.get("150").getNivel());
		//System.out.println(mapa.get("150").getNome());
		Cargo resposta = mapa.get(JOptionPane.showInputDialog
				("Chave"));
		System.out.println(resposta.getNivel());
		System.out.println(resposta.getNome());
		System.out.println(resposta.getSalario());
	}

}











